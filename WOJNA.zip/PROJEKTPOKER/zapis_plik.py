def save_game_state():
    with open(save_file, 'wb') as file:
        pickle.dump((current_round, talia_gracz1, talia_gracz2, wygrane_rundy, przegrane_rundy, remisy), file)
def load_game_state():
    try:
        with open(save_file, 'rb') as file:
            return pickle.load(file)
    except FileNotFoundError:
        return None
if loaded_state:
    continue_game = input("Do you want to continue from the saved game? (y/n): ").lower()
    if continue_game == 'y':
        current_round, talia_gracz1, talia_gracz2, wygrane_rundy, przegrane_rundy, remisy = loaded_state