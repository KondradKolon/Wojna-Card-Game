# card_functions.py
import pygame
pygame.font.init()
font = pygame.font.SysFont(None, 18)

# Constants
CARD_WIDTH, CARD_HEIGHT = 96, 172

WIDTH, HEIGHT = 800, 600
FPS = 60
WHITE, BLACK = (255, 255, 255), (0, 0, 0)

# Function to draw a card
def draw_card(surface, card, x, y, atut_images):
    card_rect = pygame.Rect(x, y, CARD_WIDTH, CARD_HEIGHT)
    pygame.draw.rect(surface, BLACK, card_rect, 2)  # Black border

    # White fill color
    pygame.draw.rect(surface, WHITE, card_rect)

    try:
        suit_image = atut_images[card.atut]
    except KeyError:
        print(f"Error: No image found for suit '{card.atut}'")
        return

    suit_rect = suit_image.get_rect(center=(x + CARD_WIDTH // 2, y + CARD_HEIGHT // 2))
    surface.blit(suit_image, suit_rect)

    # Display card value in each corner
    value_text = font.render(str(card.wartosc), True, BLACK)

    # Top-left corner
    tl_rect = value_text.get_rect(topleft=(x + 5, y + 5))
    surface.blit(value_text, tl_rect)

    # Top-right corner
    tr_rect = value_text.get_rect(topright=(x + CARD_WIDTH - 5, y + 5))
    surface.blit(value_text, tr_rect)

    # Bottom-left corner
    bl_rect = value_text.get_rect(bottomleft=(x + 5, y + CARD_HEIGHT - 5))
    surface.blit(value_text, bl_rect)

    # Bottom-right corner
    br_rect = value_text.get_rect(bottomright=(x + CARD_WIDTH - 5, y + CARD_HEIGHT - 5))
    surface.blit(value_text, br_rect)


# Function to draw player names
def draw_player_names(surface, player1_name, player2_name, font_size=18, center=False):
    font = pygame.font.SysFont(None, font_size)
    text_player1 = font.render(player1_name, True, WHITE)
    text_player2 = font.render(player2_name, True, WHITE)

    if center:
        text_player1_rect = text_player1.get_rect(center=(WIDTH // 2, HEIGHT - 40))
        text_player2_rect = text_player2.get_rect(center=(WIDTH // 2, 20))
    else:
        text_player1_rect = text_player1.get_rect(topleft=(20, HEIGHT - 40))
        text_player2_rect = text_player2.get_rect(topleft=(20, 20))

    surface.blit(text_player1, text_player1_rect)
    surface.blit(text_player2, text_player2_rect)
def draw_card_back(screen, x, y):
    screen.blit(screen, (x, y))

