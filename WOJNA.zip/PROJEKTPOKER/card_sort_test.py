from card_sort import bubble_sort
from Karty import *
from game_logic import play_round
from game_logic import initialize_game
from result import *
#przykladowa talia kart
talia_kart = [
    Karta('7', 'Karo', 7),
    Karta('2', 'Trefl', 2),
    Karta('A', 'Pik', 14),
    Karta('5','Kier', 5)
]
talia_kart4 = [
    Karta('3', 'Pik', 3),
    Karta('A', 'Trefl', 14),
    Karta('8', 'Pik', 8),
    Karta('2','Kier', 2)
]
talia_kart3 = [
    Karta('3', 'Karo', 3),
    Karta('2', 'Trefl', 2),
    Karta('A', 'Pik', 14),
    Karta('5','Kier', 5)
]
screen1=None
def test_initialize_game():
    assert len(initialize_game()[1]) == 26 and len(initialize_game()[2]) == 26

def test_bubble_sort():
    assert bubble_sort(talia_kart) == sorted(talia_kart, key=lambda karta: karta.waga)
def test_war():
    assert play_round(talia_kart3,talia_kart4) == 2