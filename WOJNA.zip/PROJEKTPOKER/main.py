# main.py
import pygame
import sys
from card_functions import draw_card, draw_player_names
from game_logic import initialize_game, play_round
from Karty import *
from card_sort import *
from result import draw_result,win_image,win_sound,lose_image,lose_sound,draw_image,draw_sound
import pickle

# music
pygame.mixer.init()
pygame.mixer.music.load('AUDIO/samurai.mp3')
pygame.mixer.music.play(-1)
# Constants
pygame.font.init()
font = pygame.font.SysFont(None, 24)  # Increased font size
WIDTH, HEIGHT, = 800, 600
FPS = 60
WHITE, BLACK = (255, 255, 255), (0, 0, 0)
CARD_WIDTH, CARD_HEIGHT = 80, 120
timer_start_time = pygame.time.get_ticks()
# Load card images
atut_images = {suit: pygame.image.load(f"IMAGES/{suit}.png") for suit in ["Karo", "Pik", "Trefl", "Kier"]}
card_back = pygame.image.load("IMAGES/card_back.png")
# Initialize Pygame
pygame.init()
# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("WOJNA")
clock = pygame.time.Clock()
# Game variables
current_round, timer, remis, pokuj = 1, 1, 0, 0
# TaliaKart instance and other setup
talia1, talia_gracz1, talia_gracz2 = initialize_game()
# player scores
wygrane_rundy = 0
przegrane_rundy = 0
remisy=0
player1_name, player2_name = input("Jak masz na imie:"), "Komputer"
z=int(input("Ile rund chcesz zagrac:"))
#gamestate
save_file = 'game_state.pkl'
def save_game_state():
    with open(save_file, 'wb') as file:
        pickle.dump((current_round, talia_gracz1, talia_gracz2, wygrane_rundy, przegrane_rundy, remisy), file)
def load_game_state():
    try:
        with open(save_file, 'rb') as file:
            return pickle.load(file)
    except FileNotFoundError:
        return None
loaded_state = load_game_state()
if loaded_state:
    continue_game = input("Do you want to continue from the saved game? (y/n): ").lower()
    if continue_game == 'y':
        current_round, talia_gracz1, talia_gracz2, wygrane_rundy, przegrane_rundy, remisy = loaded_state
# Main game loop
running = True
while running and current_round <= z:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            screen.fill((34, 177, 55))
            # Draw player names with increased font size and centered
            draw_player_names(screen, player1_name, player2_name, font_size=24, center=True)
            #draw first round
            remaining_deck_x, remaining_deck_y = 500, 350
            screen.blit(card_back, (remaining_deck_x, remaining_deck_y))
            remaining_deck_x, remaining_deck_y = 220, 30
            screen.blit(card_back, (remaining_deck_x, remaining_deck_y))
            # Draw card values and simulate card animation
            if talia_gracz1 and talia_gracz2:

                # print("Talia Gracza 1:", [str(karta) for karta in talia_gracz1])
                # print("Talia Gracza 2:", [str(karta) for karta in talia_gracz2])
                j,karta_gracz1,karta_gracz2= play_round(talia_gracz1,talia_gracz2)
                # print(j, len(talia_gracz1), len(talia_gracz1))
                if j == 1:
                    wygrane_rundy += 1
                elif j == 0:
                    przegrane_rundy += 1
                else:
                    remisy += 1
                card_x, card_y = WIDTH // 2 - CARD_WIDTH // 2, HEIGHT // 2 - CARD_HEIGHT // 2
                # Draw player 1 card
                draw_card(screen, karta_gracz2, card_x, card_y-200, atut_images)
                # Draw player 2 card with a small gap
                draw_card(screen, karta_gracz1, card_x, card_y+100, atut_images)
                #scoreboard
                wynik = font.render(f"W:{wygrane_rundy}  L:{przegrane_rundy}  D:{remisy}", True, WHITE)
                screen.blit(wynik, (360, 530))
                draw_result(j,400,300,screen)
                # Timer
                timer_text = font.render(f"Runda nr: {current_round}", True, WHITE)
                screen.blit(timer_text, (WIDTH - 150, 20))
                # Update the display
                pygame.display.flip()
                current_round += 1
                # Introduce a delay to slow down the card animations
                pygame.time.delay(10)  # Adjust the delay time (in milliseconds) as needed
                # Increment timer on each iteration
                timer += 1
                # Draw card back for the remaining deck
                remaining_deck_x, remaining_deck_y = 500, 350
                screen.blit(card_back, (remaining_deck_x, remaining_deck_y))
                remaining_deck_x, remaining_deck_y = 220, 30
                screen.blit(card_back, (remaining_deck_x, remaining_deck_y))
                save_game_state()
                if current_round == z:
                    print(
                        f"{len(talia_gracz1)} Końcowa Talia Gracza {player1_name}: {[str(karta) for karta in bubble_sort(talia_gracz1)]}")
                    print(
                        f"{len(talia_gracz2)} Końcowa Talia Komputera: {[str(karta) for karta in bubble_sort(talia_gracz2)]}")
                    koniec(talia_gracz1,talia_gracz2)
                # Update the display
                pygame.display.flip()
    # Cap the frame rate
    clock.tick(FPS)
# Quit Pygame
pygame.quit()
sys.exit()