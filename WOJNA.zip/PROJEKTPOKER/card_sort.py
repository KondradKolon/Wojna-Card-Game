from Karty import *

def bubble_sort(talia_kart):

    n = len(talia_kart)

    for i in range(n):
        for j in range(0, n - i - 1):
            if talia_kart[j].waga > talia_kart[j + 1].waga:
                talia_kart[j], talia_kart[j + 1] = talia_kart[j + 1], talia_kart[j]

    return talia_kart
def koniec(talia1,talia2):
    if len(talia1) > len(talia2):
        print("WYGRAŁEŚ WOJNE")
    elif len(talia1) < len(talia2):
        print("PRZEGRAŁEŚ WOJNE")
    else:
        print("REMIS")
