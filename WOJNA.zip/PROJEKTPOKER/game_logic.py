# game_logic.py
from Karty import *
def initialize_game():
    talia1 = TaliaKart()
    talia1.stworz_talie()
    talia1.tasuj()
    talia_gracz1 = []
    talia_gracz2 = []
    # Dobranie i rozdanie wszystkich kart
    for i in range(26):
        # Dobranie karty dla obu graczy
        karta_gracz1 = talia1.dobierz_karte()
        karta_gracz2 = talia1.dobierz_karte()
        # Dodanie kart do talii odpowiednich graczy
        talia_gracz1.append(karta_gracz1)
        talia_gracz2.append(karta_gracz2)
    return talia1, talia_gracz1, talia_gracz2
def play_round(talia_gracz1, talia_gracz2):
    # print(len(talia_gracz1), len(talia_gracz2))
    # Check if any player is out of cards
    if not talia_gracz1 or not talia_gracz2:
        print("Game over. One of the players is out of cards.")
        return talia_gracz1, talia_gracz2, remis, pokuj
    karta_gracz1 = talia_gracz1.pop(0)
    # Check if player 2 is out of cards after player 1 draws
    if not talia_gracz2:
        print("Player 2 is out of cards.")
        return talia_gracz1, talia_gracz2
    karta_gracz2 = talia_gracz2.pop(0)
    # print(f"Gracz 1: {karta_gracz1} vs Gracz 2: {karta_gracz2}")
    # print(karta_gracz1.wartosc,karta_gracz2.wartosc,karta_gracz1.waga,karta_gracz2.waga,karta_gracz1.waga > karta_gracz2.waga)
    if karta_gracz1.waga > karta_gracz2.waga:
        talia_gracz1.extend([karta_gracz1, karta_gracz2])
        # print("1 wygrał")
        return 1,karta_gracz1,karta_gracz2

    elif karta_gracz1.waga < karta_gracz2.waga:
        talia_gracz2.extend([karta_gracz1, karta_gracz2])
        return 0,karta_gracz1,karta_gracz2

    elif karta_gracz1.waga == karta_gracz2.waga:
        # print("remis")
        talia_gracz2.extend([karta_gracz2])
        talia_gracz1.extend([karta_gracz1])
        return 2, karta_gracz1, karta_gracz2

        # zakryta_gracz1 = talia_gracz1.pop(0)
        #
        # # Check if player 2 is out of cards after player 1 draws the hidden card
        # if not talia_gracz2:
        #     print("Player 2 is out of cards.")
        #     talia_gracz1.append(zakryta_gracz1)  # Return the hidden card to player 1
        #     return talia_gracz1, talia_gracz2
        #
        # zakryta_gracz2 = talia_gracz2.pop(0)
        # karta2_gracz2 = talia_gracz2.pop(0)
        # karta2_gracz1 = talia_gracz1.pop(0)
        #
        # if karta2_gracz1.waga > karta2_gracz2.waga:
        #     talia_gracz1.extend([karta_gracz1, karta_gracz2, zakryta_gracz2, zakryta_gracz1, karta2_gracz1, karta2_gracz2])
        #     print("1 wygrał wojnę")
        #     return 1
        # elif karta2_gracz1.waga < karta2_gracz2.waga:
        #     talia_gracz2.extend([karta_gracz1, karta_gracz2, zakryta_gracz2, zakryta_gracz1, karta2_gracz1, karta2_gracz2])
        #     print("2 wygrał wojnę")
        #     return 2
        #
        # elif karta2_gracz1.waga == karta2_gracz2.waga:
        #     print("remis")
        #
        #     zakryta2_gracz1 = talia_gracz1.pop(0)
        #     zakryta2_gracz2 = talia_gracz2.pop(0)
        #     karta3_gracz2 = talia_gracz2.pop(0)
        #     karta3_gracz1 = talia_gracz1.pop(0)
        #
        #     # Check if player 2 is out of cards after player 1 draws the second hidden card
        #     if not talia_gracz2:
        #         print("Player 2 is out of cards.")
        #         talia_gracz1.extend([zakryta_gracz1, zakryta_gracz2, karta2_gracz1, karta2_gracz2, zakryta2_gracz1])
        #         talia_gracz1.extend([zakryta2_gracz2, karta3_gracz1, karta3_gracz2])  # Return the hidden cards to player 1
        #         return talia_gracz1, talia_gracz2
        #
        #     if karta3_gracz1.waga > karta3_gracz2.waga:
        #         talia_gracz1.extend([karta_gracz1, karta_gracz2, zakryta_gracz2, zakryta_gracz1,
        #                              karta2_gracz1, karta2_gracz2, karta3_gracz1, karta3_gracz2,
        #                              zakryta2_gracz2, zakryta2_gracz1])
        #         print("1 wygrał wojnę")
        #         return 1
        #     elif karta3_gracz1.waga < karta3_gracz2.waga:
        #         talia_gracz2.extend([karta_gracz1, karta_gracz2, zakryta_gracz2, zakryta_gracz1,
        #                              karta2_gracz1, karta2_gracz2, karta3_gracz1, karta3_gracz2,
        #                              zakryta2_gracz2, zakryta2_gracz1])
        #         print("2 wygrał wojnę")
        #         return 2
        #     else:
        #         return 3
        #         print("pokój")
        #         return 4
        #         talia_gracz2.extend([karta_gracz2, zakryta_gracz2, karta2_gracz2, zakryta2_gracz2, karta3_gracz2])
        #         talia_gracz2.extend([karta_gracz1, zakryta_gracz1, karta2_gracz1, zakryta2_gracz1, karta3_gracz1])
        #         talia_gracz1.extend([karta_gracz1, zakryta_gracz1, karta2_gracz1, zakryta2_gracz1, karta3_gracz1])
        #         talia_gracz1.extend([karta_gracz2, zakryta_gracz2, karta2_gracz2, zakryta2_gracz2, karta3_gracz2])
    return talia_gracz1, talia_gracz2
# def kto_wygral(karta1,karta2):
#     if karta1.waga > karta1.waga:
#         return 1
#     if karta1.waga > karta1.waga:
#         return 2