#run_game.py
from main import main_game_loop

# Run the main game loop
main_game_loop()
