# result_display.py
import pygame
import sys

# Initialize Pygame
pygame.mixer.init()
pygame.font.init()

# Load images and sounds
win_image = pygame.image.load("IMAGES/Win.png")
lose_image = pygame.image.load("IMAGES/Lose.png")
draw_image = pygame.image.load("IMAGES/Draw.png")
win_sound = pygame.mixer.Sound("AUDIO/win.mp3")
lose_sound = pygame.mixer.Sound("AUDIO/lose.mp3")
draw_sound = pygame.mixer.Sound("AUDIO/draw.mp3")

def draw_result(result, x, y,screen):
    if result == 1:
        result_image = win_image
        result_sound = win_sound
    elif result == 0:
        result_image = lose_image
        result_sound = lose_sound
    elif result == 2:
        result_image = draw_image
        result_sound = draw_sound
    else:
        return  # No action for other results

    # Play the sound
    result_sound.play()

    # Display the image at custom coordinates on the screen
    image_rect = result_image.get_rect(center=(x, y))
    screen.blit(result_image, image_rect)

    # Wait for a few seconds (adjust as needed)
    pygame.time.delay(3)

