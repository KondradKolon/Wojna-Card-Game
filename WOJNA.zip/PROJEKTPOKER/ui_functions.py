#ui_functions.py
from main import *
# Function to draw player names
def draw_player_names(surface, player1_name, player2_name,wygrane_rundy,przegrane_rundy, HEIGHT, WHITE):

    text_player1 = font.render(player1_name, True, WHITE)
    text_player2 = font.render(player2_name,,f"W:{wygrane_rundy}f"L:{przegrane_rundy}, WHITE)

    surface.blit(text_player1, (20, HEIGHT - 40))
    surface.blit(text_player2, (20, 20))
def draw_card_back(screen, x, y):
    screen.blit(card_back, (x, y))

# Inside your main game loop
remaining_deck_x, remaining_deck_y = 500, 350
draw_card_back(screen, remaining_deck_x, remaining_deck_y)

remaining_deck_x, remaining_deck_y = 220, 30
draw_card_back(screen, remaining_deck_x, remaining_deck_y)



