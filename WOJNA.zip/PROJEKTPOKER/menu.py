# not using this, wanted to but didnt in the end saving it so i correct can corect ti in the future


# import pygame
# class Button:
#     def __init__(self, rect, text, action):
#         self.rect = pygame.Rect(rect)
#         self.text = text
#         self.action = action
#         self.clicked = False
#
#     def draw(self, surface, font):
#         pygame.draw.rect(surface, (255, 0, 0), self.rect)  # Red button
#         text_surface = font.render(self.text, True, (255, 255, 255))  # White text
#         text_rect = text_surface.get_rect(center=self.rect.center)
#         surface.blit(text_surface, text_rect)
#
#     def handle_event(self, event):
#         if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
#             if self.rect.collidepoint(event.pos):
#                 self.clicked = True
#                 return self.action
#         return None
