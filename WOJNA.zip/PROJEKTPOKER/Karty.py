#Karty.py
import random


class Karta:
    def __init__(self, wartosc, atut,waga):
        self.wartosc = wartosc
        self.atut = atut
        self.waga = waga

    def __str__(self):
        return f"{self.wartosc} {self.atut}"


class TaliaKart:
    def __init__(self):
        self.karty = []

    def stworz_talie(self):
        atuty = ["Pik", "Kier", "Trefl", "Karo"]
        wartosci = [str(i) for i in range(2, 11)] + ["J", "Q", "K", "A"]

        for atut in atuty:
            for wartosc in wartosci:

                waga = wartosci.index(wartosc) + 2
                self.karty.append(Karta(wartosc, atut, waga))



    def tasuj(self):
        random.shuffle(self.karty)

    def dobierz_karte(self):
        if not self.karty:
            print("Brak kart w talii.")
            return None
        else:
            return self.karty.pop()


# Stworzenie talii kart
talia1 = TaliaKart()
talia1.stworz_talie()

# Tasowanie talii
talia1.tasuj()
talia1.tasuj()
talia1.tasuj()

# karty w reku gracza
talia_gracz1 = []
talia_gracz2 = []

# Dobranie i rozdanie wszystkich kart
for i in range(26):
    # Dobranie karty dla obu graczy
    karta_gracz1 = talia1.dobierz_karte()
    karta_gracz2 = talia1.dobierz_karte()

    # Dodanie kart do talii odpowiednich graczy
    talia_gracz1.append((karta_gracz1))
    talia_gracz2.append((karta_gracz2))





def handle_draw(talia, remis, pokuj):
    remis += 1
    hidden_cards = []

    for _ in range(2):
        hidden_cards.append(talia.pop(0))

    if hidden_cards[0].wartosc > hidden_cards[1].wartosc:
        talia.extend(hidden_cards)
        print("1 wygrał wojnę")
    elif hidden_cards[0].wartosc < hidden_cards[1].wartosc:
        print("2 wygrał wojnę")
    else:
        remis, pokuj = handle_draw(talia, remis, pokuj)

    return remis, pokuj


def runda(karta_gracz1, karta_gracz2, wygrane_rundy, przegrane_rundy, remisy, pokuj):
    if karta_gracz1.wartosc > karta_gracz2.wartosc:
        talia_gracz1.extend([karta_gracz1, karta_gracz2])
        wygrane_rundy += 1
    elif karta_gracz1.wartosc < karta_gracz2.wartosc:
        talia_gracz2.extend([karta_gracz1, karta_gracz2])
        przegrane_rundy += 1
    else:
        print("remis")
        remisy, pokuj = handle_draw(talia_gracz1, remisy, pokuj)

    return wygrane_rundy, przegrane_rundy, remisy, pokuj


def handle_round(talia_gracz1, talia_gracz2, remis, pokuj):
    karta_gracz1 = talia_gracz1.pop(0)
    karta_gracz2 = talia_gracz2.pop(0)

    print(f"Gracz 1: {karta_gracz1} vs Gracz 2: {karta_gracz2}")

    if karta_gracz1.wartosc > karta_gracz2.wartosc:
        talia_gracz1.extend([karta_gracz1, karta_gracz2])
        print("1 wygrał")
    elif karta_gracz1.wartosc < karta_gracz2.wartosc:
        talia_gracz2.extend([karta_gracz1, karta_gracz2])
        print("2 wygrał")
    else:
        print("remis")
        remis, pokuj = handle_draw(talia_gracz1, remis, pokuj)

    return remis, pokuj


def gra(ilosc_rund, remis=0, pokuj=0):
    for runda in range(ilosc_rund):
        print(len(talia_gracz1), len(talia_gracz2))

        if not talia_gracz1 or not talia_gracz2:
            print("Game over. One of the players is out of cards.")
            return remis, pokuj

        remis, pokuj = handle_round(talia_gracz1, talia_gracz2, remis, pokuj)

    return remis, pokuj







