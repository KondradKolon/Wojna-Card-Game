# not using this, wanted to but didnt in the end saving it so i correct can corect ti in the future

import pygame
from pygame.locals import *

# Inicjalizacja Pygame
pygame.init()

# Ustawienia okna
WIDTH, HEIGHT = 800, 600
FPS = 60

# Ustawienia kolorów
WHITE = (255, 255, 255)

# Ustawienia suwaka
slider_width, slider_height = 20, 200
slider_rect = pygame.Rect(50, 50, slider_width, slider_height)
slider_color = (0, 128, 255)
slider_value = 10
slider_min, slider_max = 1, 100

# Ustawienia etykiety
font = pygame.font.Font(None, 36)
label_text = f"Rounds: {slider_value}"
label = font.render(label_text, True, (0, 0, 0))
label_rect = label.get_rect(center=(WIDTH // 2, 20))

def run_slider():
    running = True
    sliding = False

    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            elif event.type == MOUSEBUTTONDOWN:
                if slider_rect.collidepoint(event.pos):
                    sliding = True
            elif event.type == MOUSEBUTTONUP:
                sliding = False
            elif event.type == MOUSEMOTION and sliding:
                slider_value = max(slider_min, min(slider_max, slider_value + event.rel[1]))

        slider_rect.y = (slider_value - slider_min) / (slider_max - slider_min) * (HEIGHT - slider_height)

        screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Slider Example")

        # Rysowanie suwaka
        pygame.draw.rect(screen, slider_color, slider_rect)
        pygame.draw.rect(screen, (255, 0, 0), slider_rect.inflate(10, 0))

        # Rysowanie etykiety
        label_text = f"Rounds: {int(slider_value)}"
        label = font.render(label_text, True, (0, 0, 0))

        # Aktualizacja ekranu
        screen.fill(WHITE)
        screen.blit(label, label_rect)
        pygame.display.flip()
        pygame.time.Clock().tick(FPS)

    pygame.quit()
    return slider_value

if __name__ == "__main__":
    slider_value = run_slider()
    print("Selected Rounds:", int(slider_value))
